P=linux32 L="-s -static-libgcc" D=libunibreak.so A=libunibreak.a ./build.sh
