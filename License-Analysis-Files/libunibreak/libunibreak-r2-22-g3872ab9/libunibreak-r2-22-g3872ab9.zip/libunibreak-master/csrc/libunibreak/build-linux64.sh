P=linux64 C=-fPIC L="-s -static-libgcc" D=libunibreak.so A=libunibreak.a ./build.sh
