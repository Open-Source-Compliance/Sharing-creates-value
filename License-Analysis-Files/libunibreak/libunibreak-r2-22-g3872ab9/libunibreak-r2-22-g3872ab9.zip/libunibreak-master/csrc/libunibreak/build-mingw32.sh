P=mingw32 L="-s -static-libgcc" D=unibreak.dll A=unibreak.a ./build.sh
