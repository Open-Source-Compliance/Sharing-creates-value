./org.test.plugins.dummyplugin/src/android/DummyPlugin.java
